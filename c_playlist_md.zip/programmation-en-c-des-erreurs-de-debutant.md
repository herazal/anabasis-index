---
title: "Programmation en C : Des erreurs de débutant !"
description: "Tour des erreurs fréquentes des débutants : variables non initialisées, dépassements de tampon, oublis de `free`, et astuces de débogage."
tags:
  - c
  - programmation
  - debutant
date: 2025-05-28
layout: video
---

[Regarder la vidéo sur YouTube](https://www.youtube.com/watch?v=U9G7G5ia_eM&list=PLYTHy808C4AAnAYPqZa_lPXDHUNaVTos1&index=12)

## Résumé technique

Tour des erreurs fréquentes des débutants : variables non initialisées, dépassements de tampon, oublis de `free`, et astuces de débogage.

## Autres vidéos dans la série

- [Programmation en C : Introduction et HelloWorld !](programmation-en-c-introduction-et-helloworld.md)
- [Programmation en C : Afficher des caractères à l’écran : la fonction write](programmation-en-c-afficher-des-caracteres-a-lecran-la-fonction-write.md)
- [Programmation en C : Introduction à la récursivité](programmation-en-c-introduction-a-la-recursivite.md)
- [Programmation en C : Les pointeurs (théorie)](programmation-en-c-les-pointeurs-theorie.md)
- [Programmation en C : Les pointeurs (pratique et exercices)](programmation-en-c-les-pointeurs-pratique-et-exercices.md)
- [Programmation en C : Initiation à la programmation modulaire](programmation-en-c-initiation-a-la-programmation-modulaire.md)
- [Programmation en C : La fonction printf](programmation-en-c-la-fonction-printf.md)
- [Programmation en C : Instructions conditionnelles : if et else](programmation-en-c-instructions-conditionnelles-if-et-else.md)
- [Programmation en C : Opérateurs de comparaison logique](programmation-en-c-operateurs-de-comparaison-logique.md)
- [Programmation en C : Les boucles](programmation-en-c-les-boucles.md)
- [Programmation en C : Les bonnes pratiques !](programmation-en-c-les-bonnes-pratiques.md)
- [Programmation en C : malloc(), free(), allocation dynamique](programmation-en-c-malloc-free-allocation-dynamique.md)
- [Programmation en C : Les variables et leurs types !](programmation-en-c-les-variables-et-leurs-types.md)
